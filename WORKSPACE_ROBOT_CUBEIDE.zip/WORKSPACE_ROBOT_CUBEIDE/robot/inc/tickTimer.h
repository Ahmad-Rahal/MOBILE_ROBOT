/*
 * TickTimer.h
 */

#ifndef INC_TICKTIMER_H_
#define INC_TICKTIMER_H_

#include "main.h"

void tickTimerInit(void);




#endif /* INC_TICKTIMER_H_ */
